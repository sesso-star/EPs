package futebol;

class BeisebolForcaCalculator implements ForcaCalculator {
    public int calc(Stats stats) {
        return 1;
    }
}
