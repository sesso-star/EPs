package futebol;

interface ForcaCalculator {
    public int calc(Stats stats);
}
