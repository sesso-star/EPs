package futebol;

class FutebolForcaCalculator implements ForcaCalculator {
    public int calc(Stats stats) {
        return 1;
    }
}
