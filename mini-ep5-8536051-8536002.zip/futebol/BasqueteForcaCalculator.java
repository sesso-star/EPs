package futebol;

class BasqueteForcaCalculator implements ForcaCalculator {
    public int calc(Stats stats) {
        return 1;
    }
}
