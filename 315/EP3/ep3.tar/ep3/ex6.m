% Este teste tem A com posto inclompleto
A = [1, 1, 1, -1, 0;
     1, 1, 1,  0, 1;
     0, 0, 0,  1, 1]; % esta restrição é LD com as duas ultimas
b = [1; 2; 1];
c = -[1; 1; 0.5; 0; 0];
m = 3;
n = 5;

