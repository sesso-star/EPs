% um exemplo em que todos tem custo igual
A = ones(1, 3);
b = 1;
x = [1; 0; 0];
c = -[1; 1; 1];
m = 1;
n = 3;

esp = [1; 0; 0];
